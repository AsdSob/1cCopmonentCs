﻿namespace AsterNET.Manager.Action
{
    public class CoreSettingsAction : ManagerAction
    {
        public override string Action
        {
            get { return "CoreSettings"; }
        }
    }
}