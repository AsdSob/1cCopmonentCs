namespace AsterNET.Manager.Action
{
    public abstract class ProxyAction : ManagerAction
    {
    }
}