﻿namespace AsterNET.Manager.Action
{
    public class CoreStatusAction : ManagerAction
    {
        public override string Action
        {
            get { return "CoreStatus"; }
        }
    }
}