﻿namespace AsterNET.Manager.Action
{
    public class CoreShowChannelsAction : ManagerAction
    {
        public override string Action
        {
            get { return "CoreShowChannels"; }
        }
    }
}