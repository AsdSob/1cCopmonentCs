﻿namespace AsterNET.Manager.Action
{
    internal class ListCommandsAction
    {
    }
}