# AsteriskAddIn1C
AddIn for 1C:Enterprise platform, built on Native Api technology and based on AsterNET project
